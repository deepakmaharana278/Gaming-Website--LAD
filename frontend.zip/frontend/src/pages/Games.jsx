import { useEffect, useState } from "react";

export default function Games() {
  const [games, setGames] = useState([]);

  useEffect(() => {
    fetch("http://127.0.0.1:8000/api/games/")
      .then((res) => res.json())
      .then((data) => setGames(data));
  }, []);

  return (
    <div className="p-6 grid grid-cols-2 md:grid-cols-4 gap-6">
      {games.map((g, i) => (
        <div
          key={i}
          className="bg-gray-900 rounded-xl shadow hover:scale-105 transition"
        >
          <img
            src={g.thumb}
            alt={g.title}
            className="rounded-t-xl w-full h-40 object-cover"
          />

          <div className="p-3 text-white">
            <h3 className="font-semibold">{g.title}</h3>
            <p className="text-sm text-gray-400">{g.category}</p>

            <a
              href={g.url}
              target="_blank"
              rel="noreferrer"
              className="block mt-2 text-center bg-purple-600 rounded py-1 hover:bg-purple-700"
            >
              Play Now
            </a>
          </div>
        </div>
      ))}
    </div>
  );
}
